package com.zybooks.personalweightmonitor.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = { User.class, Weight.class }, version = 1)
public abstract class AppDataBase extends RoomDatabase {

    public abstract UserDao userDao();
    public abstract WeightDao weightDAO();

    private static final String DATABASE_NAME = "appdata.db";
    private static AppDataBase INSTANCE;

    // Singleton
    public static AppDataBase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDataBase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDataBase.class,
                            DATABASE_NAME)
                            .fallbackToDestructiveMigration()
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
