package com.zybooks.personalweightmonitor.globals;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.zybooks.personalweightmonitor.R;
import com.zybooks.personalweightmonitor.db.AppDataBase;
import com.zybooks.personalweightmonitor.db.Weight;
import com.zybooks.personalweightmonitor.db.WeightDao;
import com.zybooks.personalweightmonitor.fragment.WeightPickerFragment;
import com.zybooks.personalweightmonitor.recycler.WeightListAdapter;
import com.zybooks.personalweightmonitor.recycler.WeightViewerFragMngr;

import java.util.List;


public class WeightViewerFragment extends Fragment
        implements View.OnClickListener {

    private static final String TAG = WeightViewerFragment.class.getSimpleName();

    private static CurrentUser mCurrentUser;
    private WeightDao mWeightDao;
    private AppDataBase db;
    private List<Weight> mWeights;
    private WeightViewerFragMngr fm;


    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weight_items_viewer,
                container,
                false);

        fm = WeightViewerFragMngr.getINSTANCE();


        // Add the following lines to create RecyclerView
        Context context = this.getContext();
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        final WeightListAdapter adapter = new WeightListAdapter(context);
        recyclerView.setAdapter(adapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setLayoutManager(new LinearLayoutManager(context));

        FloatingActionButton fabAddWeight = view.findViewById(R.id.fab_add_weight);
        fabAddWeight.setOnClickListener(this);

        db = AppDataBase.getDatabase(context);
        mWeightDao = db.weightDAO();
        mCurrentUser = CurrentUser.newInstance();
        mWeights = mWeightDao.getUserWeightMeasurements(mCurrentUser.getUser().id);

        adapter.setWeights(mWeights);

        return view;
    }

    @Override
    public void onResume(){
        super.onResume();

    }

    @Override
    public void onClick(View view) {
        // TODO put in Add Weight functionality

        Snackbar.make(getView(),
                "FAB Add Weight button clicked.",
                Snackbar.LENGTH_LONG)
                .show();


        fm.setFragMan(getParentFragmentManager());


        getParentFragmentManager()
                .beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragmentContainerView_mainActivity, WeightPickerFragment.class, null)
                .commit();


    }



}