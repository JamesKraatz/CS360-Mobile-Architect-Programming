package com.zybooks.personalweightmonitor.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.personalweightmonitor.R;
import com.zybooks.personalweightmonitor.db.AppDataBase;
import com.zybooks.personalweightmonitor.db.User;
import com.zybooks.personalweightmonitor.db.Weight;
import com.zybooks.personalweightmonitor.db.WeightDao;
import com.zybooks.personalweightmonitor.fragment.AddWeightFragment;
import com.zybooks.personalweightmonitor.globals.CurrentUser;
import com.zybooks.personalweightmonitor.globals.CurrentWeight;

import java.util.List;

public class WeightListAdapter extends RecyclerView.Adapter<WeightListAdapter.WeightViewHolder> {

    // private static final String TAG = WeightListAdapter.class.getSimpleName();

    private LayoutInflater mInflater;
    private List<Weight> mWeights; // Cached copy of weights
    private CurrentUser mCurrentUser;
    private CurrentWeight mCurrentWeight;

    private AppDataBase db;
    private WeightDao mWeightDao;
    private List<Weight> weights;
    private Context mContext;
    private View mView;

    public WeightListAdapter(Context context) { mInflater = LayoutInflater.from(context); }

//    private static final int ITEM_COUNT = 50;
//    private List<Weight> mWeights;
//    private AppDataBase db;
//    private UserDao userDao;
//    private WeightDao weightDao;
//    private User mUser;
//    private Weight mWeight;

    @Override
    public WeightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.fragment_weight_items_viewer, parent, false);
        mCurrentUser = CurrentUser.newInstance();
        mContext = parent.getContext();
        View mView = parent.getRootView();
        AppDataBase db = AppDataBase.getDatabase(parent.getContext());
        WeightDao weightDao = db.weightDAO();
        mWeights = weightDao.getUserWeightMeasurements(mCurrentUser.getUser().id);

        return new WeightViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(WeightViewHolder holder, int position) {
        // muser should only have one user in it
        if (mWeights != null && mCurrentUser.getUser() != null) {
            Weight currWeight = mWeights.get(position);
            User currUser = mCurrentUser.getUser();   // should always be the only user
            holder.dateItemView.setText(currWeight.date);
            holder.weightItemView.setText(currWeight.weight);
            String uom;
            if(currUser.unit_of_measure == 1) { uom = "kg"; } else { uom = "lbs"; };
            holder.uomItemView.setText(uom);

            View itemContainer = mViewHolderView.findViewById(R.id.weight_item_container);
            itemContainer.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v){
                    // get weight
                    mCurrentWeight.setPosition(holder.getAbsoluteAdapterPosition());
                    Weight weight = mWeights.get(mCurrentWeight.getPosition());
                    // call update
                    mCurrentWeight = CurrentWeight.getINSTANCE();
                    mCurrentWeight.setWeight(weight);
                    mCurrentWeight.setPosition(mCurrentWeight.getPosition());
                    if(mCurrentUser.getUser().unit_of_measure == 1) {
                        mCurrentWeight.setUom("kg");
                    } else { mCurrentWeight.setUom("lbs"); }
                    updateWeight();
                    return true;
                }


            });

            Button btnDelete = mViewHolderView.findViewById(R.id.weightDate);
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // get weight
                    Weight weight = mWeights.get(holder.getAbsoluteAdapterPosition());
                    // call delete record
                    mWeightDao.deleteUser(weight);
                    // clear the cache
                    mWeights.clear();
                    // reload thre records
                    mWeights = mWeightDao.getUserWeightMeasurements(mCurrentUser.getUser().id);
                }
            });


        } else {
            // Covers the case of daa not being ready yet.

            holder.weightItemView.setText("No Weight");
        }

//        final Weight weightMeas = mWeights.get(position);
//
//        // convert weight to desired units
//        int weight = weightMeas.weight;
//        int pounds = WeightUnitOfMeasure.POUNDS.getValue();
//        if (mUser.unit_of_measure == pounds) {
//            // comvert grams to pounds
//            weight = (int) (weight * 0.00220462);
//            String uom = "LBS";
//        } else {
//            // convert grams to kilgrams
//            weight = (int) (weight / 1000);
//            String uom = "kg";
//        }
//
//        holder.date.setText(weightMeas.date);
//        holder.weight.setText(weightMeas.weight);
//        holder.unit.setText("kg");
    }

    private void updateWeight() {

        FragmentManager fm = WeightViewerFragMngr.getINSTANCE().getFragMan();

        mView.findViewById(R.id.fragmentContainerView_mainActivity).setVisibility(View.VISIBLE);


        fm.beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragmentContainerView_mainActivity, AddWeightFragment.class, null)
                .commit();

    }


    public void setWeights(List<Weight> weights) {
        mWeights = weights;
    }

    // getItemCount() is called many times, and when it is first called,
    // mWeights has not bee update (means initially, it's null, and we can't return null)
    @Override
    public int getItemCount() {
        if (mWeights != null) {
            return mWeights.size();
        } else return 0;
    }


//    public WeightListAdapter(Context context) {
//        super();
//
//        // Set up data information
//        db = AppDataBase.getDatabase(context.getApplicationContext());
//        userDao = db.userDao();
//
//        if(context instanceof MainActivity) {
//            MainActivity activity = (MainActivity) context;
//            mUser = activity.getCurrentUser();
//        }
//
//        weightDao = db.weightDAO();
//        mWeights = weightDao.getUserWeightMeasurements(mUser.id);
//

        // Old static stuff replace with data from db
//        Resources res = context.getResources();
//        String[] weightDates = res.getStringArray(R.array.dates);
//        String[] weightValues = res.getStringArray(R.array.weights);
//        for (int i = 0; i < weightDates.length; i++) {
//            String date = weightDates[i];
//            WeightUnitOfMeasure unit = WeightUnitOfMeasure.POUNDS;
//            try {
//                int weight = parseInt(weightValues[i]);
//                mWeights.add(new Weight( i + 1, date, weight, unit.getValue()));
//            } catch (ParseException e) {
//                e.printStackTrace();
//            }
//        }
//        // Replace above stuff
//    }


//    @Override
//    public int getItemCount() {
//        return mWeights.size();
//    }

    private static View mViewHolderView;
    public static class WeightViewHolder extends RecyclerView.ViewHolder {
//        implements View.OnLongClickListener {

        private TextView dateItemView;
        private TextView weightItemView;
        private TextView uomItemView;

        public WeightViewHolder(View itemView) {
            super(itemView);

            mViewHolderView = itemView;

            this.dateItemView = itemView.findViewById(R.id.weightDate);
            this.weightItemView = itemView.findViewById(R.id.weightValue);
            this.uomItemView = itemView.findViewById(R.id.weightUnit);
        }

//        @Override
//        public boolean onLongClick(View view) {
//            Snackbar.make(view,
//                    "Weight Entry was long clicked.",
//                    Snackbar.LENGTH_LONG)
//                    .show();
//
//            return false;
//        }

    }
}