package com.zybooks.personalweightmonitor.globals;

import com.zybooks.personalweightmonitor.db.User;

public class CurrentUser {

    private static User mUser;
    private static boolean mIsLoggedIn;
    private static CurrentUser INSTANCE = null;

    public static CurrentUser newInstance() {
        if(INSTANCE == null) {
            INSTANCE = new CurrentUser();
            setLoggedIn(false);
        }
        return INSTANCE;
    }

    public static User getUser() {
        return mUser;
    }

    public static void setUser(User user) {
        mUser = user;
    }

    public static boolean isLoggedIn() {
        return mIsLoggedIn;
    }

    public static void setLoggedIn(boolean mIsLoggedIn) {
        CurrentUser.mIsLoggedIn = mIsLoggedIn;
    }
}
