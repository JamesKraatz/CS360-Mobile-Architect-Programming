package com.zybooks.personalweightmonitor.activity;

import static android.Manifest.permission.SEND_SMS;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.zybooks.personalweightmonitor.R;

public class PermissionActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int PERMISSION_REQUEST_CODE = 100;
    public static final String  EXTRA_PERMISSION_CODE =
            "com.zybooks.personalweightmonitor.permission";
    private View mView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        // specify the toolbar layout
        Toolbar childToolbar =  (Toolbar) findViewById(R.id.child_toolbar);
        this.setSupportActionBar(childToolbar);

        // get support for actionBar corresponding to this toolbar
        ActionBar actionBar = this.getSupportActionBar();

        // enable the Up button
        actionBar.setDisplayHomeAsUpEnabled(true);

        Button check_permission = findViewById(R.id.check_permission);
        Button request_permission = findViewById(R.id.request_permission);
        check_permission.setOnClickListener(this);
        request_permission.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        mView = v;

        int id = v.getId();

        if(id == R.id.check_permission) {
            if (checkPermission()) {

                Snackbar.make(mView, R.string.PermissionPreviouslyGrantedMessage, Snackbar.LENGTH_LONG).show();

            } else {

                Snackbar.make(mView, R.string.RequestPermissoinMessage, Snackbar.LENGTH_LONG).show();
            }
        }
        else if (id == R.id.request_permission) {
            if (!checkPermission()) {

                requestPermission();

            } else {

                Snackbar.make(mView, "Permission already granted.", Snackbar.LENGTH_LONG).show();
            }
        }

        finish();

    }

    private boolean checkPermission() {
        Context context = getApplicationContext();
        int result = ContextCompat.checkSelfPermission(context, SEND_SMS);

        return result == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{SEND_SMS}, PERMISSION_REQUEST_CODE);

    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == PERMISSION_REQUEST_CODE && grantResults.length > 0) {
            boolean sendSmsAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (sendSmsAccepted) {
                Snackbar.make(mView, "Permission Granted, SMS updates can be sent.", Snackbar.LENGTH_LONG).show();
            } else {

                Snackbar.make(mView, "Permission Denied, SMS updates cannot be sent.", Snackbar.LENGTH_LONG).show();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (shouldShowRequestPermissionRationale(SEND_SMS)) {
                        showMessageOKCancel(
                                (dialog, which) -> {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermissions(new String[]{SEND_SMS},
                                                PERMISSION_REQUEST_CODE);
                                    }
                                });
                    } else {

                        Snackbar.make(mView,
                                R.string.PermissionPreviouslyDeniedMessage,
                                Snackbar.LENGTH_LONG).show();
                    }
                }
            }
            // return permission
            Intent intent = new Intent();
            intent.putExtra(EXTRA_PERMISSION_CODE, grantResults[0]);
            setResult(RESULT_OK, intent);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);

    }

    private void showMessageOKCancel(DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(PermissionActivity.this)
                .setMessage(R.string.PermissionDialogMessage)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
}