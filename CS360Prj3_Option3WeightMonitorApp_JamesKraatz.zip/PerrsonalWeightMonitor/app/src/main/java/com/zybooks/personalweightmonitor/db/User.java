package com.zybooks.personalweightmonitor.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "login_name")
    public String login_name;

    @ColumnInfo(name = "password")
    public String password;

    @ColumnInfo(name = "unit_of_measure")
    public int unit_of_measure;

    @ColumnInfo(name = "weight_goal_type")
    public int type_goal_type;

    @ColumnInfo(name = "upper_weight")
    public int upper_weight;

    @ColumnInfo(name = "lower_weight")
    public int lower_weight;

}
