package com.zybooks.personalweightmonitor.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDao {

    // (C)reate of CRUD
    // Creates a single user
    @Insert
    public void createNewUser(User user);

    // (R)ead of CRUD
    // Reads one user from the table that matches loginName
    @Query("SELECT * FROM users WHERE login_name = :loginName")
    public List<User> getUserByLoginName(String loginName);

    // (U)pdate of CRUD
    // Updates record of User
    @Update
    public void updateUser(User... users);

    // (D)elete of CRUD
    // Delete User record
    @Delete
    public void deleteUser(User... users);

}
