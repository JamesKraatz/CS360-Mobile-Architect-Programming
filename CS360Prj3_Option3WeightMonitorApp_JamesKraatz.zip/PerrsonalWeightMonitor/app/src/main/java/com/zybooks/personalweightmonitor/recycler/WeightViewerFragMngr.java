package com.zybooks.personalweightmonitor.recycler;

import androidx.fragment.app.FragmentManager;

public class WeightViewerFragMngr {
    private static FragmentManager mFragMan;
    private static WeightViewerFragMngr INSTANCE = null;

    public static WeightViewerFragMngr getINSTANCE() {
        if(INSTANCE == null) {
            INSTANCE = new WeightViewerFragMngr();
        }
        return INSTANCE;
    }

    public static FragmentManager getFragMan() {
        return mFragMan;
    }

    public static void setFragMan(FragmentManager FragMan) {
        mFragMan = FragMan;
    }
}
