package com.zybooks.personalweightmonitor.db;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="weights")
public class Weight {


    @PrimaryKey(autoGenerate = true)
    @NonNull
    public int id;

    @ColumnInfo(name = "user_id")
    public int user_id;

    @ColumnInfo(name = "date")
    public String date;

    @ColumnInfo(name = "weight")
    public int weight;
}
