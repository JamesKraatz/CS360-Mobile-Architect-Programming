package com.zybooks.personalweightmonitor.db;

import java.util.HashMap;
import java.util.Map;

public enum WeightGoalType {
    LOSE_WEIGHT (1),
    GAIN_WEIGHT (2),
    REMAIN_BELOW_WEIGHT (3),
    REMAIN_ABOVE_WEIGHT (4),
    REMAIN_WITHIN_WEIGHT_RANGE (5);

    private int value;
    private static Map map = new HashMap<>();

    private WeightGoalType(int i) {
        this.value = i;


    }

    static {
        for (WeightGoalType T : WeightGoalType.values()) {
            map.put(T.value, T);
        }
    }

    public WeightGoalType valueOf(int type) {
        return (WeightGoalType) map.get(type);
    }

    public int getValue() {
        return value;
    }
}
