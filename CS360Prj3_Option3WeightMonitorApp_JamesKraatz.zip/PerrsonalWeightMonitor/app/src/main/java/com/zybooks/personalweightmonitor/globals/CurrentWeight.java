package com.zybooks.personalweightmonitor.globals;

import com.zybooks.personalweightmonitor.db.Weight;

public class CurrentWeight {

    private static CurrentWeight INSTANCE = null;
    private static Weight mWeight = null;
    private static int mPosition;
    private static String mUom;

    public static CurrentWeight getINSTANCE() {
        if(INSTANCE == null) {
            INSTANCE = new CurrentWeight();
        }
        return INSTANCE;
    }


    public static Weight getWeight() {
        return mWeight;
    }

    public static void setWeight(Weight mWeight) {
        CurrentWeight.mWeight = mWeight;
    }

    public static int getPosition() {
        return mPosition;
    }

    public static void setPosition(int position) {
        CurrentWeight.mPosition = position;
    }

    public static String getUom() {
        return mUom;
    }

    public static void setUom(String uom) {
        CurrentWeight.mUom = uom;
    }
}
