package com.zybooks.personalweightmonitor.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import com.zybooks.personalweightmonitor.MainActivity;
import com.zybooks.personalweightmonitor.R;
import com.zybooks.personalweightmonitor.db.AppDataBase;
import com.zybooks.personalweightmonitor.db.User;
import com.zybooks.personalweightmonitor.db.UserDao;
import com.zybooks.personalweightmonitor.db.WeightGoalType;
import com.zybooks.personalweightmonitor.db.WeightUnitOfMeasure;
import com.zybooks.personalweightmonitor.globals.CurrentUser;

import java.util.List;

public class LoginFragment extends Fragment implements View.OnClickListener {
    private Button btnLogin;
    private Button btnRegister;
    private OnFragmentInteractionListener mListener;
    private CurrentUser mCurrentUser;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle args) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        btnLogin = (Button) view.findViewById(R.id.login_button);
        btnLogin.setOnClickListener(this);
        btnRegister = (Button) view.findViewById(R.id.register_button);
        btnRegister.setOnClickListener(this);

        mCurrentUser = CurrentUser.newInstance();

        return view;
    }

    public LoginFragment() {
        super(R.layout.fragment_login);

    }

    // Interface definition and onFeedbackChoice() callback
    public interface OnFragmentInteractionListener {
        void onUserChange(User user);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof  OnFragmentInteractionListener) {
            mListener =
                    (OnFragmentInteractionListener) context;
        } else {
            throw new ClassCastException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onClick(View v) {
        // TODO check for button click here
        // get id of button clicked
        int button_clicked = v.getId();

        // First, was the login button clicked
        if(button_clicked==R.id.login_button) {
            // if yes, then verify log-in
            performLogIn();
        }
        // Second, was the register button clicked
        else if (button_clicked==R.id.register_button) {
            // if yes, then register user
            createUser();
        // user event is not recognized, call super
        }
    }

    private void performLogIn() {
        // get username and password from view widgets
        View v = this.getView();
        EditText etUserName = (EditText) v.findViewById(R.id.editTextUserName);
        EditText etPassword = (EditText) v.findViewById(R.id.editTextPassword);

        String userName = etUserName.getText().toString();
        String userPwd = etPassword.getText().toString();

        // get a user object first
        Context context = getContext().getApplicationContext();
        AppDataBase db = AppDataBase.getDatabase(context);

        UserDao userDao = db.userDao();
        User user = null;

        // get a user matching the user login
        List<User> users = userDao.getUserByLoginName(userName);

        // make sure it is just one record
        int entries = users.size();
        boolean success = entries == 1;

        // check password
        if(success) user = users.get(0);
        success = (success && (userPwd.equals(user.password)));

        // if everything is good, proceed back to calling activity
        if(success) {
            // login was a success

            // Load preferences
            // TODO
        } else {
            // login failed

        }

        mListener.onUserChange(user);

        // Exit Fragment
        exit();
    }

    private void createUser() {
        // TODO write code to create new user
        // get username and password from view widgets
        View v = this.getView();
        EditText etUserName = (EditText) v.findViewById(R.id.editTextUserName);
        EditText etPassword = (EditText) v.findViewById(R.id.editTextPassword);

        String userName = etUserName.getText().toString();
        String userPwd = etPassword.getText().toString();

        // get a user object first
        Context context = getContext().getApplicationContext();
        AppDataBase db = AppDataBase.getDatabase(context);

        UserDao userDao = db.userDao();

        // get a user matching the user login
        List<User> user = userDao.getUserByLoginName(userName);

        // make sure login name is unique
        int entries = user.size();
        boolean success = entries == 0;

        // construct user
        User newUser = new User();
        newUser.login_name = userName;
        newUser.password  = userPwd;
        // default settings
        newUser.unit_of_measure = WeightUnitOfMeasure.POUNDS.getValue();
        newUser.type_goal_type = WeightGoalType.LOSE_WEIGHT.getValue();
        newUser.upper_weight = 999;
        newUser.lower_weight = 0;

        // add the newUser to the database
        userDao.createNewUser(newUser);

        // exit fragment
        ;
        mListener.onUserChange(newUser);
        exit();
    }

    private void onBackPressed() {
        exit();
    }

    private void exit() {
        MainActivity activity = (MainActivity) getActivity();
        activity.closeLoginFragment();
    }

}