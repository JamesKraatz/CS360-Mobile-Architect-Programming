package com.zybooks.personalweightmonitor.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightDao {

    // (C)reate of CRUD
    // Creates a single weight measurement
    @Insert
    public void addNewWeightMeasurement(Weight weight);

    // (R)ead of CRUD
    // Reads all weight measurements matching userId
    @Query("SELECT * FROM weights WHERE user_id = :userId ORDER BY date DESC")
    public List<Weight> getUserWeightMeasurements(int userId);

    // (U)pdate of CRUD
    // Updates user's weight measurements
    @Update
    public void updateUser(Weight... weights);

    // (D)elete of CRUD
    // Delete User record
    @Delete
    public void deleteUser(Weight... weights);

}
