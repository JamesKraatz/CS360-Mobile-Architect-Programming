package com.zybooks.personalweightmonitor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.snackbar.Snackbar;
import com.zybooks.personalweightmonitor.activity.PermissionActivity;
import com.zybooks.personalweightmonitor.activity.SettingsActivity;
import com.zybooks.personalweightmonitor.db.User;
import com.zybooks.personalweightmonitor.fragment.LoginFragment;
import com.zybooks.personalweightmonitor.globals.WeightViewerFragment;
import com.zybooks.personalweightmonitor.globals.CurrentUser;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener,
        LoginFragment.OnFragmentInteractionListener {

    private CurrentUser mCurrentUser;
    private Menu menu;
    private int SmsPermission = PackageManager.PERMISSION_DENIED;
    private final int REQUEST_CODE_PERMISSION = 0;
    private final int REQUEST_CODE_USER = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCurrentUser = CurrentUser.newInstance();

    }

    @Override
    protected void onResume() {
        super.onResume();

        Toolbar myToolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(myToolbar);



        if(mCurrentUser.isLoggedIn()) {
            // See if permission has been granted
            if (ContextCompat.checkSelfPermission(
                    getApplicationContext(), Manifest.permission.SEND_SMS) !=
                    PackageManager.PERMISSION_GRANTED) {
                // check activity
                startPermissionActivity();
            }

            // show weights
            showWeightMeasurements();
        }
        else
            goToLogin();
    }

    @Override
    public void onClick(View v) {

        int id = v.getId();

        if (id == R.id.login_button) {
            Snackbar.make(v, "Login button clicked.", Snackbar.LENGTH_LONG).show();
        }
        else if (id == R.id.register_button) {
            Snackbar.make(v, "Register button clicked.", Snackbar.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        this.menu = menu;
        MenuItem action_logout = menu.findItem(R.id.action_logout);
        action_logout.setVisible(mCurrentUser.isLoggedIn());

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // get id of menu item selected
        int itemId = item.getItemId();

        // perform activity of selected menu item
        if(itemId == R.id.action_settings) {
            // launch the preferences fragment
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
        }
        else if(itemId == R.id.action_logout) {
            // TODO put in logout functionality
            item.setVisible(false);
            goToLogin();
        }
        else {
            // getting here means the user's action was not recognized
            // invoke the superclass to handle it.
            return super.onOptionsItemSelected(item);
        }

        return true;
    }

    @Override
    public void onUserChange(User user) {

        CurrentUser.setLoggedIn(user != null);
        if(CurrentUser.isLoggedIn()) {
            CurrentUser.setUser(user);
        }
    }

    public void startPermissionActivity() {

        Intent intent = new Intent(this, PermissionActivity.class);
        startActivityForResult(intent, REQUEST_CODE_PERMISSION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_PERMISSION) {
            SmsPermission = data.getIntExtra(
                    PermissionActivity.EXTRA_PERMISSION_CODE,
                    PackageManager.PERMISSION_DENIED);

        }
    }

    private void showWeightMeasurements() {
        getSupportFragmentManager()
                .beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragmentContainerView_mainActivity, WeightViewerFragment.class, null)
                .commit();
    }

    private void goToLogin() {
        getSupportFragmentManager()
                .beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragmentContainerView_mainActivity, LoginFragment.class, null)
                .commit();
    }

    public void showUpButton() { getSupportActionBar().setDisplayHomeAsUpEnabled(true); }

    public void hideUpButton() { getSupportActionBar().setDisplayHomeAsUpEnabled(false); }

    public void updateMenu() { invalidateOptionsMenu(); }

    public void closeLoginFragment() {
        // Get the FragmentManager
        FragmentManager fragmentManager = getSupportFragmentManager();
        // Check to see if the fragment is already showing.
        LoginFragment loginFragment = (LoginFragment)  fragmentManager
                .findFragmentById(R.id.fragmentContainerView_mainActivity);
        if(loginFragment != null) {
            //Create and commit the transaction to remove the fragment.
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.remove(loginFragment).commit();
        }
        this.onResume();
    }
}