package com.zybooks.personalweightmonitor.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.NumberPicker;

import androidx.fragment.app.Fragment;

import com.zybooks.personalweightmonitor.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link WeightPickerFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WeightPickerFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private int weight = 0;
    private int prevWeight = 0;

//    public WeightPickerFragment() {
//        // Required empty public constructor
//    }
//
//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     * @param param1 Parameter 1.
//     * @param param2 Parameter 2.
//     * @return A new instance of fragment WeightPickerFagment.
//     */
//    // TODO: Rename and change types and number of parameters
//    public static WeightPickerFragment newInstance() {
////    public static WeightPickerFragment newInstance(String param1, String param2) {
//        WeightPickerFragment fragment = new WeightPickerFragment();
//        Bundle args = new Bundle();
////        args.putString(ARG_PARAM1, param1);
////        args.putString(ARG_PARAM2, param2);
////        fragment.setArguments(args);
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() == null) {
////            mParam1 = getArguments().getString(ARG_PARAM1);
////            mParam2 = getArguments().getString(ARG_PARAM2);
//
//
//
//
//        }
//    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weight_picker, container, false);

        weight = prevWeight;

        // set up the hundreds column
        NumberPicker hundreds =  view.findViewById(R.id.npWeightHundreds);
        hundreds.setMinValue(0);
        hundreds.setMaxValue(9);
        hundreds.setValue(getHundreds(prevWeight));
        hundreds.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                upDateWeight(weight, numberPicker.getValue(), 100);
            }
        });

        // set up the tens column
        NumberPicker tens = view.findViewById(R.id.npWeightPickerTens);
        tens.setMinValue(0);
        tens.setMaxValue(9);
        tens.setValue(getTens(prevWeight));
        tens.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                upDateWeight(weight, numberPicker.getValue(), 10);
            }
        });

        // set up the ones column
        NumberPicker ones = view.findViewById(R.id.npWeightPickerOnes);
        ones.setMinValue(0);
        ones.setMaxValue(9);
        ones.setValue(getOnes(prevWeight));
        ones.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                upDateWeight(weight, numberPicker.getValue(), 1);
            }
        });

        Button btnAccept = view.findViewById(R.id.bthWeightPickerAccept);
        btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Weight changed, update weight item


                // Exit

            }
        });

        Button btnCancel = view.findViewById(R.id.btnWeightPickerCancel);
        btnCancel.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // No Change, just exit

            }
        }));

        return view;
    }


    private void upDateWeight(int oldVal, int newVal, int weight) {
        // parse weight into exponent ints of base number
        int ones = oldVal % 10;
        int tens = (oldVal - ones) % 100;
        int hundreds = oldVal - ones - tens;

        if(weight == 1) { ones = newVal; }
        else if(weight == 10) { tens = newVal * 10; }
        else { hundreds = newVal * 100; }

        weight = hundreds + tens + ones;
    }

    private void resetWeight() { weight = prevWeight; }

    private int getHundreds(int val) {
        return val - (val % 10);
    }

    private int getTens(int val) {
        return (val - (val % 10) % 100);
    }

    private int getOnes(int val) {
        return (val % 10);
    }

//    getWeightVal(hundreds_val, tens_val, ones_val)
}