package com.zybooks.personalweightmonitor.db;

import java.util.HashMap;
import java.util.Map;

public enum WeightUnitOfMeasure {
    KILOGRAMS (1),
    POUNDS (2);

    private int value;
    private static Map map = new HashMap<>();

    private WeightUnitOfMeasure(int i) {
        this.value = i;


    }

    static {
        for (WeightUnitOfMeasure T : WeightUnitOfMeasure.values()) {
            map.put(T.value, T);
        }
    }

    public WeightUnitOfMeasure valueOf(int uom) {
        return (WeightUnitOfMeasure) map.get(uom);
    }

    public String getLabel(int uom) {
        if(uom == 1 ) {
            return "kg";
        } else {
            return "lbs"; }
    }

    public int getValue() {
        return value;
    }
}
